import type { Metadata } from "next";
import Link from "next/link";
import { checkoutConfig } from "@/data/checkout";
import { ClearCart } from "@/components/clear-cart";

export const metadata: Metadata = { title: "Order status", robots: { index: false } };

type Outcome = "success" | "pending" | "failure";

async function verifyPaystack(reference: string): Promise<boolean> {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key) return false;
  try {
    const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      headers: { Authorization: `Bearer ${key}` },
      cache: "no-store",
    });
    if (!res.ok) return false;
    const data = (await res.json()) as { status?: boolean; data?: { status?: string } };
    return data.status === true && data.data?.status === "success";
  } catch {
    return false;
  }
}

export default async function CompletePage({ searchParams }: { searchParams: Promise<{ reference?: string; trxref?: string; method?: string }> }) {
  const q = await searchParams;
  const reference = q.reference ?? q.trxref;

  let outcome: Outcome = "failure";
  if (reference) outcome = (await verifyPaystack(reference)) ? "success" : "failure";
  else if (q.method === "usdc") outcome = "pending";

  const copy = checkoutConfig[outcome];
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center gap-8 px-6 py-32 text-center">
      {outcome !== "failure" && <ClearCart />}
      <h1 className="gold-text font-display text-5xl font-light">{copy.title}</h1>
      <span className="h-px w-12 bg-champagne-500" aria-hidden="true" />
      <p className="leading-relaxed text-muted">{copy.body}</p>
      {reference && outcome === "success" && <p className="text-xs tracking-[0.25em] text-champagne-700">{reference}</p>}
      <Link href={copy.cta.href} className="btn btn-outline">{copy.cta.label}</Link>
    </div>
  );
}
