import { products } from "@/data/products";
import { categories } from "@/data/categories";
import type { Product, StockStatus } from "./types";

export const getAllProducts = () => products;
export const getProduct = (slug: string) => products.find((p) => p.slug === slug);
export const getFeaturedProducts = () => products.filter((p) => p.featured);
export const getCategories = () => categories;
export const getCategory = (id: string) => categories.find((c) => c.id === id);
export const getProductsByCategory = (id?: string) =>
  id ? products.filter((p) => p.categoryId === id) : products;
export const getRelatedProducts = (p: Product, limit = 3) =>
  products.filter((x) => x.categoryId === p.categoryId && x.slug !== p.slug).slice(0, limit);
export const isPurchasable = (s: StockStatus) => s !== "out_of_stock";
