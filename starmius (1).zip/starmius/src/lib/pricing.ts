import { site } from "@/data/site";
import { getProduct, isPurchasable } from "./products";
import { round2 } from "./format";
import type { Product } from "./types";

export interface CartLine {
  slug: string;
  qty: number;
}

export interface PricedLine {
  product: Product;
  qty: number;
  lineNGN: number;
  lineUSDC: number;
}

export interface PricedCart {
  items: PricedLine[];
  unavailable: string[];
  subtotalNGN: number;
  subtotalUSDC: number;
  shippingNGN: number;
  shippingUSDC: number;
  totalNGN: number;
  totalUSDC: number;
}

/** Shared by the cart UI and the server payment routes, so totals always agree. */
export function priceCart(lines: CartLine[]): PricedCart {
  const items: PricedLine[] = [];
  const unavailable: string[] = [];

  for (const line of lines) {
    const product = getProduct(line.slug);
    const qty = Math.min(Math.max(Math.floor(line.qty), 1), site.maxQty);
    if (!product || !isPurchasable(product.stock)) {
      unavailable.push(line.slug);
      continue;
    }
    items.push({
      product,
      qty,
      lineNGN: product.priceNGN * qty,
      lineUSDC: round2(product.priceUSDC * qty),
    });
  }

  const subtotalNGN = items.reduce((s, i) => s + i.lineNGN, 0);
  const subtotalUSDC = round2(items.reduce((s, i) => s + i.lineUSDC, 0));
  const hasItems = items.length > 0;
  const shippingNGN = hasItems ? site.shipping.flatNGN : 0;
  const shippingUSDC = hasItems ? site.shipping.flatUSDC : 0;

  return {
    items,
    unavailable,
    subtotalNGN,
    subtotalUSDC,
    shippingNGN,
    shippingUSDC,
    totalNGN: subtotalNGN + shippingNGN,
    totalUSDC: round2(subtotalUSDC + shippingUSDC),
  };
}
