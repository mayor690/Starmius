import { site } from "@/data/site";
import type { StockStatus } from "@/lib/types";

export function StockBadge({ status }: { status: StockStatus }) {
  if (status === "in_stock") return null;
  return <span className="text-[0.62rem] uppercase tracking-[0.3em] text-champagne-700">{site.stockLabels[status]}</span>;
}
