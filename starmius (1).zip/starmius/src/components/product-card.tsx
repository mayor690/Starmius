import Link from "next/link";
import type { Product } from "@/lib/types";
import { getCategory } from "@/lib/products";
import { Price } from "./price";
import { ProductVisual } from "./product-visual";
import { StockBadge } from "./stock-badge";

export function ProductCard({ product }: { product: Product }) {
  const category = getCategory(product.categoryId);
  return (
    <article className="group">
      <Link href={`/product/${product.slug}`} className="block">
        <ProductVisual product={product} className="aspect-[4/5]" />
        <div className="mt-6 flex flex-col items-center gap-2 text-center">
          {category && <p className="eyebrow !text-[0.62rem]">{category.name}</p>}
          <h3 className="font-display text-2xl font-light">{product.name}</h3>
          <Price priceNGN={product.priceNGN} priceUSDC={product.priceUSDC} />
          <StockBadge status={product.stock} />
        </div>
      </Link>
    </article>
  );
}

export function ProductGrid({ products, empty }: { products: Product[]; empty: string }) {
  if (!products.length) return <p className="text-center text-muted">{empty}</p>;
  return (
    <div className="grid grid-cols-2 gap-x-6 gap-y-14 lg:grid-cols-3 lg:gap-x-10">
      {products.map((p) => <ProductCard key={p.slug} product={p} />)}
    </div>
  );
}
