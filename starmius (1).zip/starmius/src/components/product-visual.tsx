import Image from "next/image";
import type { Product } from "@/lib/types";

export function ProductVisual({ product, className = "", priority = false, sizes = "(min-width: 1024px) 30vw, 50vw" }: { product: Product; className?: string; priority?: boolean; sizes?: string }) {
  const src = product.images[0];
  return (
    <div className={`relative overflow-hidden bg-gradient-to-br from-ivory-100 via-ivory-200 to-champagne-200/60 ${className}`}>
      {src ? (
        <Image src={src} alt={product.name} fill sizes={sizes} priority={priority} className="object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
      ) : (
        <>
          <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_20%_0%,rgba(233,205,160,0.5),transparent_70%)]" />
          <span className="absolute inset-0 grid place-items-center" aria-hidden="true">
            <svg viewBox="0 0 24 24" className="sparkle size-10 text-champagne-500" fill="currentColor">
              <path d="M12 0c.6 6.5 5.5 11.4 12 12-6.5.6-11.4 5.5-12 12-.6-6.5-5.5-11.4-12-12C6.5 11.4 11.4 6.5 12 0z" />
            </svg>
          </span>
        </>
      )}
    </div>
  );
}
