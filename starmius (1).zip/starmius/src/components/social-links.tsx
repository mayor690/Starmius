import { socials } from "@/data/socials";
import { Icon } from "./icons";

export function SocialLinks({ context, className = "" }: { context: "footer" | "contact"; className?: string }) {
  const items = socials.filter((s) => (context === "footer" ? s.showInFooter !== false : s.showInContact !== false));
  return (
    <ul className={`flex flex-wrap items-center gap-5 ${className}`}>
      {items.map((s) => (
        <li key={s.id}>
          <a href={s.url} target="_blank" rel="noopener noreferrer" aria-label={s.label} className="inline-flex text-champagne-500 transition-colors hover:text-champagne-300">
            <Icon name={s.icon} className="size-6" />
          </a>
        </li>
      ))}
    </ul>
  );
}
