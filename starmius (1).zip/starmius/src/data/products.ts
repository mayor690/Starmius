import type { Product } from "@/lib/types";

/**
 * SAMPLE PRODUCTS. Replace with your real catalogue.
 *
 * To add a product: copy one block, give it a unique `slug`, set `categoryId`
 * to an id from categories.ts, and fill both prices. No other file changes.
 * To remove a product: delete its block.
 * To show a product on the home page: set `featured: true`.
 * Images: drop files in /public/products and list paths, e.g. ["/products/x.jpg"].
 */
export const products: Product[] = [
  {
    slug: "radiant-face-cream",
    name: "Radiant Face Cream",
    tagline: "Soft, luminous daily moisture",
    description:
      "A silky, lightweight face cream that melts into the skin and leaves a calm, dewy finish. Made for everyday use, morning and night.",
    categoryId: "face-creams",
    priceNGN: 18000,
    priceUSDC: 12,
    stock: "in_stock",
    images: [],
    size: "50 ml",
    featured: true,
    benefits: ["Lightweight, non greasy feel", "Soft, even looking glow", "Suits daily use"],
    ingredients: "Add the full ingredient list here.",
    howToUse: "Apply a small amount to clean skin, morning and night.",
  },
  {
    slug: "luminous-night-cream",
    name: "Luminous Night Cream",
    tagline: "Nourishing overnight comfort",
    description:
      "A richer cream designed for evening rituals. Wake up to skin that feels cushioned, soft and rested.",
    categoryId: "face-creams",
    priceNGN: 22000,
    priceUSDC: 15,
    stock: "in_stock",
    images: [],
    size: "50 ml",
    featured: true,
    benefits: ["Rich overnight texture", "Soft, comfortable feel by morning"],
    ingredients: "Add the full ingredient list here.",
    howToUse: "Smooth over face and neck after cleansing, before bed.",
  },
  {
    slug: "silk-body-cream",
    name: "Silk Body Cream",
    tagline: "Velvety all over softness",
    description:
      "A generous body cream with a smooth, matte finish. Absorbs gracefully and leaves skin soft to the touch.",
    categoryId: "body-creams",
    priceNGN: 20000,
    priceUSDC: 14,
    stock: "in_stock",
    images: [],
    size: "250 ml",
    featured: true,
    benefits: ["Smooth, matte finish", "Absorbs without stickiness"],
    ingredients: "Add the full ingredient list here.",
    howToUse: "Massage over body after bathing.",
  },
  {
    slug: "golden-glow-body-butter",
    name: "Golden Glow Body Butter",
    tagline: "Deep comfort with a soft sheen",
    description:
      "A whipped body butter for dry days and special evenings. Leaves a delicate, polished glow.",
    categoryId: "body-creams",
    priceNGN: 24000,
    priceUSDC: 16,
    stock: "low_stock",
    images: [],
    size: "250 ml",
    benefits: ["Whipped, indulgent texture", "Subtle, polished glow"],
    ingredients: "Add the full ingredient list here.",
    howToUse: "Warm a small amount between palms and apply to damp skin.",
  },
  {
    slug: "even-tone-serum",
    name: "Even Tone Serum",
    tagline: "A light layer of radiance",
    description:
      "A weightless serum that layers beautifully under cream. Part of your daily enhancement routine.",
    categoryId: "enhancement",
    priceNGN: 26000,
    priceUSDC: 18,
    stock: "preorder",
    images: [],
    size: "30 ml",
    benefits: ["Weightless layering", "Pairs with any Starmius cream"],
    ingredients: "Add the full ingredient list here.",
    howToUse: "Apply two to three drops before moisturiser.",
  },
  {
    slug: "signature-glow-set",
    name: "Signature Glow Set",
    tagline: "Face and body, together",
    description: "Our face cream and body cream, paired in one considered set.",
    categoryId: "enhancement",
    priceNGN: 36000,
    priceUSDC: 25,
    stock: "out_of_stock",
    images: [],
    benefits: ["Face and body in one set"],
  },
];
