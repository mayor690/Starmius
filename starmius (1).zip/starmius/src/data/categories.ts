import type { Category } from "@/lib/types";

/** Add a category here and reference its id from products. */
export const categories: Category[] = [
  { id: "face-creams", name: "Face Creams", description: "Daily care for a calm, luminous complexion." },
  { id: "body-creams", name: "Body Creams", description: "Rich, soft textures for skin that glows." },
  { id: "enhancement", name: "Enhancement", description: "Targeted beauty and enhancement essentials." },
];
